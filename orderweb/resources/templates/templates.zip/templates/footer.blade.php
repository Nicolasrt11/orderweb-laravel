<!DOCTYPE html>
<html>    
    <body>
              
        <footer class="sticky-footer bg-white">
            <div class="container my-auto">
                <div class="copyright text-center my-auto">
                    <span>Copyright &copy; XXXXXX</span>
                </div>
            </div>
        </footer>
        
    </body>
</html>
